let getJokeData = ()=>{
    $("#letsBtn").remove();
    $("#jokeBtn").css("margin" , "auto");
    $("#jokeBtn").show();

    let joke1 = document.getElementById("joke");
    let jokeBtn = document.getElementById("jokeBtn");
    
    let createJoke = async () => {
        let config = {
          headers: { Accept: "application/json" },
        };
        let res = await fetch("https://icanhazdadjoke.com/", config);
        let data = await res.json();
        joke1.innerHTML = data.joke;

      };

    createJoke();
    
    jokeBtn.addEventListener("click", () => createJoke());
    
}

